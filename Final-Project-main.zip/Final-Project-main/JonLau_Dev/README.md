Final Project
Selected Topic
Our selected topic is healthcare, specifically the rollout of the COVID-19 vaccine. 

Question:
IWhat is the Impact of Death rate with Vaccination

Data Source

https://catalog.data.gov/dataset/provisional-weekly-deaths-by-region-race-age-62c96
https://catalog.data.gov/dataset/covid-19-vaccine-initial-allocations-pfizer
https://catalog.data.gov/dataset/covid-19-vaccine-distribution-allocations-by-jurisdiction-moderna
https://data.cdc.gov/Vaccinations/COVID-19-Vaccine-Distribution-Allocations-by-Juris/w9zu-fywh
https://data.cdc.gov/NCHS/Provisional-COVID-19-Death-Counts-by-Sex-Age-and-S/9bhg-hcku
